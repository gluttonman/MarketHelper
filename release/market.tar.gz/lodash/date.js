module.exports = {
  'now': require('./date/now')
};
