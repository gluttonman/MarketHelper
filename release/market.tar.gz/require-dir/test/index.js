require('..')('.');
console.log('\nAll tests passed!');
